package org.ycpait.geometryapp;

public class MyClass implements I1,I2 {

	@Override
	public void show() {
	}
	@Override
	public void display() {
		System.out.println("In display Of MyClass");
	}
	public static void main(String[] args) {
		I1 m = new MyClass();
		m.display();//runtime polymorphism
	}
}
