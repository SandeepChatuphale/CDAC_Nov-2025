package org.ycpait.geometryapp;

public interface I1 {

	void show();
	default void display() {
		System.out.println("In display() of I1");
	}
}
