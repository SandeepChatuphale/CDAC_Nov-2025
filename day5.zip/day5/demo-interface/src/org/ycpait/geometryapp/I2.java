package org.ycpait.geometryapp;

public interface I2 {

	void show();
	default void display() {
		System.out.println("In display() of I1");
	}
}
