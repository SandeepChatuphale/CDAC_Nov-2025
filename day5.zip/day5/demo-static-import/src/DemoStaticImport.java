
import static java.lang.System.out;

public class DemoStaticImport {

	public static void main(String[] args) {

			
		out.println("IN");
		out.println("Java");
		out.println("World");
	}

}
