package org.ycpait.studentmanagementapp.entity;

public class Trainer {

	
}
