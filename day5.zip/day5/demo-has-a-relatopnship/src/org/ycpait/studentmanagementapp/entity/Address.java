package org.ycpait.studentmanagementapp.entity;

public class Address {

	private String city;
	private int pincode;
}
