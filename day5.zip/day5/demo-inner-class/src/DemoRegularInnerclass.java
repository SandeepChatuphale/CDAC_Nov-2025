
//outer class
public class DemoRegularInnerclass {
	
	//regular inner class
	class Inner{
		//
	}
	
	void display() {
		class MethodLocal{}
	}
	
	static class StaticInner{}
	
	
	
	

}
