
public interface Searchable {

	boolean search(String data);
}
