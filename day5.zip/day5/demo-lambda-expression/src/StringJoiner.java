
public interface StringJoiner {

	String join(String s1,String s2);
}
