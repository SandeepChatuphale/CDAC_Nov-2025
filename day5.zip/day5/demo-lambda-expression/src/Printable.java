
@FunctionalInterface
public interface Printable {
		void print();
}
