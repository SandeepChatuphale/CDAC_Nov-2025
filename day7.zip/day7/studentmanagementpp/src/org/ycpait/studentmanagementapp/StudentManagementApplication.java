package org.ycpait.studentmanagementapp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.ycpait.studentmanagementapp.entity.Student;
import org.ycpait.studentmanagementapp.exception.StudentNotFoundException;

public class StudentManagementApplication {
	public static void main(String[] args) {

		System.out.println("Number of Students registered are " + Student.getCount());
		//Student[] students = new Student[2];
		List<Student> students = new ArrayList<Student>();

		// built-in class used to accept I/P from user
		Scanner sc = new Scanner(System.in);
		int choice = -1;
		do {
			System.out.println("Welcome to Student Management App");
			System.out.println("====================================");
			System.out.println("1. Register new Student");
			System.out.println("2. Display Details");
			System.out.println("3. Search Student By Roll number");
			System.out.println("4. Delete Student By Roll number");
			System.out.println("5. Sort Students by marks");
			System.out.println("6. Sort Students By Name");
			System.out.println("-1. Exit");
			System.out.println("Enter your choice");
			choice = sc.nextInt(); // accepting user's choice
			switch (choice) {
			case 1:
					System.out.println("Enter Name");
					String name = sc.next();
					System.out.println("Enter Marks");
					float marks = sc.nextFloat();
					Student s = new Student(name,marks);
					students.add(s);
				break;
			case 2:
				for (Student stu : students) {
					if (stu != null)
						System.out.println(stu);
				}
				break;
			case 3:
				System.out.println("Enter Roll number");
				int r = sc.nextInt();

				boolean isFound = false;
				// searching student in array
				for (Student foundStudent : students) {
					if (foundStudent != null) {
						// if student roll from array is eq to accepted rollNumber
						if (foundStudent.getRollNumber() == r) {
							System.out.println(foundStudent);
							isFound = true;
							break;
						}
					}
				}
				if (!isFound) {
					// generate Exception
					StudentNotFoundException e = new StudentNotFoundException(
							"Student with rollNumber " + r + "  NOT FOUND");
					try {
						throw e;
					} catch (StudentNotFoundException ex) {
						ex.printStackTrace();
					}
				}
				break;
				
			case 4:
				System.out.println("Enter ROll Number to Delete");
				int rollNumberToDelete = sc.nextInt();
				Iterator<Student> i = students.iterator();
				
				while(i.hasNext()) {
					Student studentTobeDeleted = i.next();
			if(studentTobeDeleted.getRollNumber() == rollNumberToDelete)
						i.remove();
				}
				break;
			case 5:
				Collections.sort(students);
				
				for (Student stu : students) {
					if (stu != null)
						System.out.println(stu);
				}	
				break;
			
			case 6:
				Collections.sort(students,
						(s1,s2)-> s1.getName().compareTo(s2.getName()));
				
				for (Student stu : students) {
					if (stu != null)
						System.out.println(stu);
				}
				break;
			case -1:
				System.out.println("Thank you visit again");
			}
		} while (choice != -1);

		// s.rollNumber = -1;//to stop this we make sure rollNumber
		// is NOT accessible outside the class
		// in which it is declared
		// s.name = "Amit";
		// s.marks = 88.89f;

	}

}
