package org.ycpait.studentmanagementapp.entity;

import java.io.Serializable;
import java.util.Comparator;

public class Student implements Serializable,Comparable<Student>{

	private static int count;
	
	//attributes OR instance variables
	private int rollNumber;
	private String name;
	private float marks;
	
	//no-arg constructor
	/*public Student(){
		System.out.println("In side Student()");
		this.rollNumber = 1;
		this.name = "Guest";
		this.marks = 50.0f;
	}*/
	

	//parameterized constructor
	public Student(String name,float marks ) {
		//System.out.println("====Parameterized constructor====");
		count++;
		this.rollNumber = count;
		this.name = name;
		this.marks = marks;
	}

	
	public int getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getMarks() {
		return marks;
	}

	public void setMarks(float marks) {
		this.marks = marks;
	}
	
	
	private static void setCount(int count) {
		Student.count = count;
	}
	
	public static int getCount() {
		return count;
	}
	
	void accept(int rollNumber,String name,float marks) {
		
		this.rollNumber = rollNumber;
		this.name = name;
		this.marks = marks;
	}
	
	//method definition
	//instance method
	void display() {
		System.out.println(this.rollNumber);
		System.out.println(this.name);
		System.out.println(this.marks);
	}
	
	
	
	//overloaded method
	void display(String format) {
		System.out.println("RollNumber \t Name \t Marks");
		for(int i = 1; i<=40;i++)
			System.out.print(format);
		
		System.out.println();//for new line
		
		System.out.println(this.rollNumber +" \t    " + this.name +"  \t   " + this.marks);	
	}
	
	
	@Override
	//overridden method
	//this method should return String which is useful information
	//about this object
	public String toString() {
		System.out.println("in toString");
		return this.rollNumber + " "+ this.name +" "+ this.marks;
	}


	@Override
	public int compareTo(Student o) {
		return (int) (marks - o.marks);
	}
	
	
}



