import java.lang.annotation.RetentionPolicy;

public class TestEnum {

	public static void main(String[] args) {
		
		GenderType m = GenderType.MALE;
		System.out.println(m);
		
		
		
		//built-in enum examples
		//RetentionPolicy.SOURCE
		
	}

}
