
public class GeometryApplication {

	public static void main(String[] args) {

		Circle c = new Circle(2, "red");
		System.out.println("Area of Circle is " + c.calculateArea());
		c.draw();
		
		/*Rectangle r = new Rectangle(2, 4, "blue");
		System.out.println("Area of Rectangle is " + r.calculateArea());
		r.draw();
		*/
		
	}

}
