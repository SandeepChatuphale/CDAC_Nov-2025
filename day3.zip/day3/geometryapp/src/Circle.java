
public class Circle extends Shape {

	private float radius;
	//private String color;

	public Circle(float radius, String color) {
		super(color);
		System.out.println("in Circle(float radius, String color)");
		this.radius = radius;
		//this.color = color;
	}
	public float calculateArea() {
		return 3.14f * radius * radius;
	}
	
	@Override //built-in annotation to check if overriding is 
			  //appropriate
			  //it is recommended to annotate for overriden methods
			  //NOT mandate
	//overridden method 
	public void draw() {
		super.draw();
		System.out.println("With radius "+ this.radius);
	}
	
	
	
	
	
	
	
	
	
	

}
