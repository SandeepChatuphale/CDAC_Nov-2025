
public class DemoManyCatches {
	public static void main(String[] args) {
		try {
			String s = null;
			System.out.println(s.length());
			System.out.println(args[0]);
			System.out.println(1/0);
		}
	/*	catch (ArithmeticException e) {
			System.out.println("Cannot divide by zero");
		}
		catch (NullPointerException e) {
System.out.println("Can not invoke method on null reference");
		}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("array index out of range");
		}*/
		catch (Exception e) {
			System.out.println("Generic");
			e.printStackTrace();
		}
		System.out.println("After");
	}

}
