public class DemoThrow {

	public static void main(String[] args) {
		
		NullPointerException e = new NullPointerException();
		throw e;
	}
}
