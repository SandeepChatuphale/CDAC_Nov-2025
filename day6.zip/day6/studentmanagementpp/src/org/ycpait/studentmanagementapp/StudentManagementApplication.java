package org.ycpait.studentmanagementapp;

import java.util.Scanner;

import org.ycpait.studentmanagementapp.entity.Student;
import org.ycpait.studentmanagementapp.exception.StudentNotFoundException;

public class StudentManagementApplication {
	public static void main(String[] args) {

		System.out.println("Number of Students registered are " + Student.getCount());

		Student s = null;

		Student[] students = new Student[2];

		// built-in class used to accept I/P from user
		Scanner sc = new Scanner(System.in);
		int choice = -1;
		int indexCount = 0;
		do {
			System.out.println("Welcome to Student Management App");
			System.out.println("====================================");
			System.out.println("1. Register new Student");
			System.out.println("2. Display Details");
			System.out.println("3. Search Student By Roll number");
			System.out.println("-1. Exit");
			System.out.println("Enter your choice");
			choice = sc.nextInt(); // accepting user's choice
			switch (choice) {
			case 1:
				if (indexCount != students.length) {
					students[indexCount] = new Student(1, "Amit", 78.78f);
					indexCount++;
				} else {
					System.err.println("Limit Exceeded");
				}
				break;
			case 2:
				for (Student stu : students) {
					if (stu != null)
						System.out.println(stu);
				}
				break;
			case 3:
				System.out.println("Enter Roll number");
				int r = sc.nextInt();

				boolean isFound = false;
				// searching student in array
				for (Student foundStudent : students) {
					if (foundStudent != null) {
						// if student roll from array is eq to accepted rollNumber
						if (foundStudent.getRollNumber() == r) {
							System.out.println(foundStudent);
							isFound = true;
							break;
						}
					}
				}
				if (!isFound) {
					// generate Exception
					StudentNotFoundException e = new StudentNotFoundException(
							"Student with rollNumber " + r + "  NOT FOUND");
					try {
						throw e;
					} catch (StudentNotFoundException ex) {
						ex.printStackTrace();
					}
				}
				break;
			case -1:
				System.out.println("Thank you visit again");
			}
		} while (choice != -1);

		// s.rollNumber = -1;//to stop this we make sure rollNumber
		// is NOT accessible outside the class
		// in which it is declared
		// s.name = "Amit";
		// s.marks = 88.89f;

	}

}
