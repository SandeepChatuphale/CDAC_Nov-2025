import java.util.ArrayList;
import java.util.List;

public class DemoProcessing {

	public static void main(String[] args) {
		List<String> cities = new ArrayList<String>();
		cities.add("Mumbai");
		cities.add("Delhi");
		cities.add("Pune");
		cities.add("Mysore");
		cities.add("Manglore");

		cities.forEach(str -> System.out.println(str));

		/*
		 * Create a new list from this existing list with cities name starting with "M"
		 */
		List<String> citiesWithM = new ArrayList<String>();

		for (String city : cities) {
			if (city.startsWith("M")) {
				citiesWithM.add(city);
			}
		}
		System.out.println(citiesWithM);

		/*
		 * Create a new list from cities list which stores length of each city
		 */
		List<Integer> citiesLength = new ArrayList<Integer>();

		for (String city : cities) {
			citiesLength.add(city.length());
		}
		System.out.println(citiesLength);

	}
}
