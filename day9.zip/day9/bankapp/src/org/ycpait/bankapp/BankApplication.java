package org.ycpait.bankapp;

import org.ycpait.bankapp.entity.Account;

public class BankApplication {

	public static void main(String[] args) {

		Account a = new Account(5000);
		

		Thread wife = new Thread(()-> a.withdraw(1000));
		wife.setName("Wife");
		

		Thread husband = new Thread(()-> a.deposit(1000));
		husband.setName("husband");
		
		wife.start();
		husband.start();
	}

}
