
public class Project {

	public void display() {}
}
