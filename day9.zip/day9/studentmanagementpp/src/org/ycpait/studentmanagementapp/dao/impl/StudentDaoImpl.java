package org.ycpait.studentmanagementapp.dao.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ycpait.studentmanagementapp.entity.Student;
import org.ycpait.studentmanagementapp.exception.StudentNotFoundException;

public class StudentDaoImpl implements Cloneable{

	private List<Student> students;

	public StudentDaoImpl() {
		this.students = new ArrayList<Student>();
	}

	public void save(Student s) {
		this.students.add(s);
	}

	public List<Student> findAll() {
		
		return students;
	}

	public Student findOne(int rollNumber) throws StudentNotFoundException {
		// searching student in list
	
//		for (Student foundStudent : students) {
//			if (foundStudent != null) {
//				// if student roll from array is eq to accepted rollNumber
//				if (foundStudent.getRollNumber() == rollNumber) {
//					return foundStudent;
//				}
//			}
//		}
		
		StudentNotFoundException e = new StudentNotFoundException(
				"Student with rollNumber " + rollNumber + "  NOT FOUND");
		return this.students.stream()
				.filter(s -> s.getRollNumber() == rollNumber)
				.findFirst()
				.orElseThrow(() -> e);
		
		//throw e;
	}

	public void deleteOne(int rollNumber) {
		
		Iterator<Student> i = students.iterator();

		while (i.hasNext()) {
			Student studentTobeDeleted = i.next();
			if (studentTobeDeleted.getRollNumber() == rollNumber)
				i.remove();
		}
	}
}