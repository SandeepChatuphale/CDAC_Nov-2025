package org.ycpait.studentmanagementapp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

import org.ycpait.studentmanagementapp.dao.impl.StudentDaoImpl;
import org.ycpait.studentmanagementapp.entity.Student;
import org.ycpait.studentmanagementapp.exception.StudentNotFoundException;

public class StudentManagementApplication {
	
	public static void main(String[] args) {
		

		System.out.println("Number of Students registered are " + Student.getCount());
		//Student[] students = new Student[2];
		//List<Student> students = new ArrayList<Student>();
		StudentDaoImpl dao = new StudentDaoImpl();
		
		// built-in class used to accept I/P from user
		Scanner sc = new Scanner(System.in);
		int choice = -1;
		do {
			System.out.println("Welcome to Student Management App");
			System.out.println("====================================");
			System.out.println("1. Register new Student");
			System.out.println("2. Display Details");
			System.out.println("3. Search Student By Roll number");
			System.out.println("4. Delete Student By Roll number");
			System.out.println("5. Sort Students by marks");
			System.out.println("6. Sort Students By Name");
			System.out.println("7. Show Top scoring students");
			System.out.println("-1. Exit");
			System.out.println("Enter your choice");
			choice = sc.nextInt(); // accepting user's choice
			switch (choice) {
			case 1:
					System.out.println("Enter Name");
					String name = sc.next();
					System.out.println("Enter Marks");
					float marks = sc.nextFloat();
					
					List<String> subjects = new ArrayList<String>();
					subjects.add("Java");
					subjects.add("Spring");
					Student s = new Student(name,marks,subjects);
					
					//students.add(s);
					dao.save(s);
				break;
			case 2:
				for (Student stu : dao.findAll()) {
					if (stu != null)
						System.out.println(stu);
				}
				break;
			case 3:
				System.out.println("Enter Roll number");
				int r = sc.nextInt();
					
				try {
					Student searchedStudent = dao.findOne(r);
					System.out.println(searchedStudent);
				} catch (StudentNotFoundException e) {
					e.printStackTrace();
				}
				
				break;
				
			case 4:
				System.out.println("Enter ROll Number to Delete");
				int rollNumberToDelete = sc.nextInt();
				
				break;
			case 5:
				Collections.sort(dao.findAll());
				
				for (Student stu : dao.findAll()) {
					if (stu != null)
						System.out.println(stu);
				}	
				break;
			
			case 6:
				Collections.sort(dao.findAll(),
						(s1,s2)-> s1.getName().compareTo(s2.getName()));
				
				for (Student stu : dao.findAll()) {
					if (stu != null)
						System.out.println(stu);
				}
				break;
				
			case 7:
				dao.findAll().stream()
				        .filter(stu -> stu.getMarks()>90)
				        .toList()
				        .forEach(stu -> System.out.println(stu));
				break;
				
			case 8:
				List<String> topScoringStudentNames = dao.findAll().stream()
				        							.filter(stu -> stu.getMarks()>90)
				        							.map(st -> st.getName())
				        							.toList();
				
				topScoringStudentNames.forEach(n -> System.out.println(n));
				break;
				
				
				
				
				
				
				
				
			case -1:
				System.out.println("Thank you visit again");
			}
		} while (choice != -1);

		// s.rollNumber = -1;//to stop this we make sure rollNumber
		// is NOT accessible outside the class
		// in which it is declared
		// s.name = "Amit";
		// s.marks = 88.89f;

	}

}
