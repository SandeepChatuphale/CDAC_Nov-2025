import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class DemoProcessing {

	public static void main(String[] args) {
		List<String> cities = new ArrayList<String>();
		cities.add("Mumbai");
		cities.add("Delhi");
		cities.add("Pune");
		cities.add("Mysore");
		cities.add("Manglore");

		cities.forEach(str -> System.out.println(str));

		/*
		 * Create a new list from this existing list with cities name starting with "M"
		 */
		List<String> citiesWithM = new ArrayList<String>();

		for (String city : cities) {
			if (city.startsWith("M")) {
				citiesWithM.add(city);
			}
		}
		System.out.println(citiesWithM);
		
		Stream<String> streamCities = cities.stream();//1
	 	Stream<String> filteredStream = streamCities.
	 									filter(c -> c.startsWith("M"));//2
		List<String> li = filteredStream.toList();//3
		
		
		
		streamCities = cities.stream();//1
	 	Stream<String> filteredStreamLength = streamCities.
	 									filter(c -> c.length()>=5);//2
		List<String> liLength = filteredStreamLength.toList();//3
		System.out.println("Length ====> " +liLength);
		

		liLength = cities.stream()
						 .filter(c -> c.length()>=5)
						 .toList();
		
		
		
		
		
		
		/*
		 * Create a new list from cities list which stores length of each city
		 */
		List<Integer> citiesLength = new ArrayList<Integer>();

		for (String city : cities) {
			citiesLength.add(city.length());
		}
		System.out.println(citiesLength);

		
		streamCities = cities.stream();//1
		Stream<Integer> lengthStream = streamCities.map(s -> s.length());
		citiesLength = lengthStream.toList();
		
		citiesLength = cities.stream()
							 .map(s -> s.length())
							 .toList();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
