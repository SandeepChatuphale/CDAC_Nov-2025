public class MyThread extends Thread {
	
	@Override
	public void run() {
		Thread c = Thread.currentThread();
		for(int i = 1;i<=5;i++) {
			System.out.println(i+ " " + c.getName());
			Thread.yield();
		}
		
	}
	public static void main(String[] args) {
		MyThread t = new MyThread();
		t.setName("hello");
		t.start();
		MyThread t1 = new MyThread();
		t1.setName("hi");
		t1.start();
		System.out.println(Thread.currentThread().getName());
		
	}

}
