package org.ycpait.geometryapp.entity;

public class Rectangle extends Shape{
	private float length;
	private float breadth;
	//private String color;

	public Rectangle(float length, float breadth, String color) {
		super(color);
		this.length = length;
		this.breadth = breadth;
		//this.color = color;
	}
	public float calculateArea() {
		return length * breadth;
	}
	@Override
	public float calculatePerimeter() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	void getInfo() {
		// TODO Auto-generated method stub
		
	}

	
}
