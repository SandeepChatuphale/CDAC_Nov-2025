package org.ycpait.geometryapp;

import org.ycpait.geometryapp.entity.Circle;
import org.ycpait.geometryapp.entity.Shape;

public class GeometryApplication {

	public static void main(String[] args) {

			Shape s;
			s = new Circle(4, "red");
			
			//invoking generalized methods
			s.calculateArea();
			s.calculatePerimeter();
			s.draw();
			
			//invoking specialized methods
			Circle c = (Circle)s; //down-casting
			c.getPi();
			
			//==========================
			Circle c1 = new Circle(12, "blue");
			//c1 = new Circle(34, "red");
			c1 = null;
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			

		
	}

}
