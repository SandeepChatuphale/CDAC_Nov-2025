package org.ycpait.library.entity;
public class Book {

}
