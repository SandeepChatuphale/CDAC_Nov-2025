package client;

import java.util.Scanner;

import org.ycpait.library.entity.Book;


public class TestLibrary {

	public static void main(String[] args) {
		
		Book b;
		Scanner sc;
		
		
		
	}
}
