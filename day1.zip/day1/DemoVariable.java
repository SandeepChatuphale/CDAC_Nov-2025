class DemoVariable{
public static void main(String[] args){

	//data_type name_of_variable;
	//byte
	//short
	int rollNumber = 10;
	System.out.println(rollNumber);
	//long

	float marks = 88.89f;
	//double
	
	char ch = 'Y';

	boolean result = true; 

	long l = 10;
	int a = 20;
	a = (int)l;//narrowing
	l = a;//widening









}
}